### covid-19-tracker
![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/ankitapuri/React-covid-19-tracker?color=red&logoColor=blue)
![](https://tokei.rs/b1/github/ankitapuri/React-covid-19-tracker)

## Description 
Covid-19 Tracker which could provide real-time analysis of the covid daily cases, recovered ones and the number of deaths incurred in the country because of covid-19.




![Stats_totalcases](imgs/pic1.png?raw=true "Title")

![Stats_recovered](imgs/pic2.png?raw=true "Title")

![Stats_death_cases](imgs/pic3.png?raw=true "Title")


## Live Link
https://covid-19-tracker-1de38.web.app/
